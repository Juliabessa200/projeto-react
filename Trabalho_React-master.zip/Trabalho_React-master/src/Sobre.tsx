import { Footer } from "./components/Footer"
import { Menu } from "./components/Menu"

export const Sobre = () =>{
    return(
        <>
        <Menu/>
        <main>
        Lorem ipsum dolor, sit amet consectetur 
        adipisicing elit. Eveniet quibusdam, minima consectetur, 
        repudiandae necessitatibus aliquid repellendus, 
        hic culpa sint recusandae magni fuga enim 
        laborum nihil accusamus consequuntur possimus reiciendis eaque.
        </main>
        <Footer/>
        </>
    )
}